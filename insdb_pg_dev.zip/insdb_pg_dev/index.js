const express = require('express');
const { Pool } = require('pg');
const fs = require('fs');
const crypto = require('crypto');
const winston = require('winston');
const expressWinston = require('express-winston');
const os = require('os');
const moment = require('moment-timezone');
const app = express();

let config;
try {
  config = require('./config.json');
} catch (err) {
  console.warn('Config file not found. Using default settings.');
  config = {};
}

const PORT = config.port || 3000;
const DB_ENDPOINT = config.dbEndpoint || '/:db/query';
const TIME_ZONE = config.timeZone || 'UTC';

const AUTH = config.auth === true || config.auth === 1 ? true : false;

const missingKeys = ['port', 'dbEndpoint', 'auth', 'timeZone'].filter(key => !(key in config));
if (missingKeys.length > 0) {
  console.warn(`Some configuration keys are missing (${missingKeys.join(', ')}). Using default settings for those.`);
}

const loggingKeys = ['appConsole', 'requestsConsole', 'appLog', 'requestsLog'];
const missingLoggingKeys = loggingKeys.filter(key => !(key in config.logging));
if (missingLoggingKeys.length > 0) {
  console.warn(`Some logging configuration keys are missing (${missingLoggingKeys.join(', ')}). Using default settings for those.`);
}

const loggerTransports = [];
if (config.logging.appConsole) {
  loggerTransports.push(new winston.transports.Console());
}
if (config.logging.appLog) {
  loggerTransports.push(new winston.transports.File({
    filename: 'app.log',
    format: winston.format.combine(
      winston.format.timestamp(),
      winston.format.json(),
      winston.format.printf((info) => {
        const { timestamp, level, message, ...meta } = info;
        const formattedTimestamp = moment(timestamp).tz(TIME_ZONE).format();
        return JSON.stringify({ timestamp: formattedTimestamp, level, message, ...meta });
      })
    ),
    options: { flags: 'a', encoding: 'utf8' }
  }));
}

const logger = winston.createLogger({
  transports: loggerTransports,
  format: winston.format.combine(
    winston.format.timestamp(),
    winston.format.json(),
    winston.format.printf((info) => {
      const { timestamp, level, message, ...meta } = info;
      const formattedTimestamp = moment(timestamp).tz(TIME_ZONE).format();
      return JSON.stringify({ timestamp: formattedTimestamp, level, message, ...meta });
    })
  )
});

const expressWinstonLoggerTransports = [];
if (config.logging.requestsConsole) {
  expressWinstonLoggerTransports.push(new winston.transports.Console());
}
if (config.logging.requestsLog) {
  expressWinstonLoggerTransports.push(new winston.transports.File({
    filename: 'requests.log',
    options: { flags: 'a', encoding: 'utf8' }
  }));
}

const expressWinstonLogger = expressWinston.logger({
  transports: expressWinstonLoggerTransports.length > 0 ? expressWinstonLoggerTransports : [new winston.transports.Console()],
  format: winston.format.combine(
    winston.format.timestamp(),
    winston.format.json(),
    winston.format.printf((info) => {
      const { timestamp, level, message, meta } = info;
      const formattedTimestamp = moment(timestamp).tz(TIME_ZONE).format();
      return `${JSON.stringify({ timestamp: formattedTimestamp, level, message, ...meta })}`;
    })
  ),
  meta: true,
  msg: (req, res) => {
    const user = (AUTH && req.headers.auth) ? req.headers.auth.split(';')[0] : 'anonymous';
    return `HTTP ${req.method} ${req.url} by ${user} from ${req.connection.remoteAddress.replace(/^.*:/, '')} on ${os.hostname()}`;
  },
  expressFormat: true,
  colorize: false,
  dynamicMeta: (req, res) => {
    const authHeader = req.headers.auth;
    let maskedAuthHeader = authHeader;
    if (authHeader && authHeader.includes(';')) {
      const [login, password] = authHeader.split(';');
      maskedAuthHeader = `${login};***`;
    }
    const reqOrder = {
      httpVersion: req.httpVersion,
      method: req.method,
      originalUrl: req.originalUrl,
      query: req.query,
      url: req.url,
      headers: {
        ...req.headers,
        auth: maskedAuthHeader
      },
      body: req.body
    };
    return {
      user: (AUTH && authHeader) ? authHeader.split(';')[0] : 'anonymous',
      ip: req.connection.remoteAddress.replace(/^.*:/, ''),
      hostname: os.hostname(),
      userAgent: req.headers['user-agent'],
      req: reqOrder,
      res: {
        statusCode: res.statusCode,
        body: JSON.parse(res.body)
      }
    };
  }
});

app.use((req, res, next) => {
  let oldSend = res.send;
  res.send = function (body) {
    res.body = body;
    res.send = oldSend;
    return res.send(body);
  };
  next();
});

app.use(express.json());
if (expressWinstonLoggerTransports.length > 0) {
  app.use(expressWinstonLogger);
}

function hashPassword(password) {
  const salt = crypto.randomBytes(16).toString('hex');
  const hash = crypto.pbkdf2Sync(password, salt, 1000, 64, 'sha512').toString('hex');
  return [salt, hash].join('$');
}

function checkPassword(password, hashedPassword) {
  const [salt, originalHash] = hashedPassword.split('$');
  const hash = crypto.pbkdf2Sync(password, salt, 1000, 64, 'sha512').toString('hex');
  return hash === originalHash;
}

app.use((req, res, next) => {
  if (!AUTH) {
    next();
  } else {
    const authData = fs.readFileSync('users.auth', 'utf8').split('\n')
      .map(line => line.trim())
      .filter(line => line);

    const authHeader = req.headers.auth;
    if (!authHeader) {
      return res.status(403).json({ error: 'Ошибка авторизации: отсутствует заголовок auth' });
    }

    const [login, password] = authHeader.split(';');
    const hashedPassword = authData.find(line => line.startsWith(`${login};`));
    if (!hashedPassword || !checkPassword(password, hashedPassword.split(';')[1])) {
      return res.status(403).json({ error: 'Ошибка авторизации: неверная пара логин;пароль' });
    }

    req.user = login;
    next();
  }
});

app.post('/crypto', express.json(), async (req, res) => {
  const authHeader = req.headers.auth;
  if (!authHeader || !authHeader.startsWith('admin;')) {
    return res.status(403).json({ error: 'Ошибка авторизации: доступ разрешен только для пользователя admin' });
  }

  const [login, password] = authHeader.split(';');

  const authData = fs.readFileSync('users.auth', 'utf8').split('\n')
    .map(line => line.trim())
    .filter(line => line);

  const hashedPassword = authData.find(line => line.startsWith(`${login};`));
  if (!hashedPassword || !checkPassword(password, hashedPassword.split(';')[1])) {
    return res.status(403).json({ error: 'Ошибка авторизации: неверная пара логин;пароль' });
  }

  const reqPassword = req.body.password;
  if (!reqPassword) {
    return res.status(400).json({ error: 'Ошибка: пароль не предоставлен' });
  }

  const hashedReqPassword = hashPassword(reqPassword);
  res.json({ hashedPassword: hashedReqPassword });
});

let dbConfig;
try {
  dbConfig = require('./dbConfig.json');
} catch (err) {
  console.error('Database configuration file not found or invalid.');
  process.exit(1);
}

const pools = {};
async function init() {
  for (const db in dbConfig) {
    try {
      const pool = new Pool(dbConfig[db]);
      pools[db] = pool;
      const client = await pool.connect();
      await client.release();
      logger.info(`Connected to ${db} Postgres database`);
    } catch (err) {
      logger.error(`Error connecting to ${db} Postgres database: ${err.message}`);
    }
  }
}

init();

for (const db in dbConfig) {
  app.post(DB_ENDPOINT, express.json(), async (req, res) => {
    const queries = Object.keys(req.body).reduce((acc, key) => {
      acc[key] = req.body[key];
      return acc;
    }, {});
    try {
      const pool = pools[db];
      const results = {};
      for (const [key, sql] of Object.entries(queries)) {
        if (!sql) {
          continue;
        }
        const result = await pool.query(sql);
        results[key] = result.rows;
      }
      res.json(results);
    } catch (err) {
      logger.error(`Error executing query on ${db} database: ${err.message}`);
      res.status(500).json({ error: `Error executing query: ${err.message}` });
    }
  });
}

app.listen(PORT, () => {
  logger.info(`Server is running on port ${PORT}`);
});